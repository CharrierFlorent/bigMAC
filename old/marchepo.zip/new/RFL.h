#ifndef H_RFL
#define H_RFL

#include "generateur.h"
#include "FC.h"

void RFL (CSP *probleme, HEURISTIQUE heuristique);

#endif
