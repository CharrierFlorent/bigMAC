#ifndef H_BT
#define H_BT
#include "structure.h"
#include "generateur.h"

void BackTrack (CSP * probleme);

#endif
