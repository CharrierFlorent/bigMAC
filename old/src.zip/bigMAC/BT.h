#ifndef H_BT
#define H_BT

#include "generateur.h"

void BackTrack (CSP *probleme);

#endif
