#ifndef H_GENERATEUR
#define H_GENERATEUR

#include "structure.h"
#include<stdio.h>
#include<stdlib.h>
#include <time.h>
#include <math.h>

CSP * generer_probleme();

#endif
