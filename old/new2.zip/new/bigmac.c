#include "bigmac.h"

CSP * create_csp(CSP * csp, int * affectation, int niveau, int size){
    int domain_size = 2;
    CSP * csp_bivalue = init_empty_csp(niveau+1, 2);
    for(int i = 0; i < niveau+1; i++)
        //for(int k = 0; k < niveau+1; k++)
            for(int j = 0; j < csp->Domain->max_domain; j++){
                csp_bivalue->Domain->domain_matrix[i][j] = 0;
                if(j == (2*(affectation[i]-1)) || j == (2*(affectation[i]-1))+1)
                    csp_bivalue->Domain->domain_matrix[i][j] = 1;
            }
	for(int i = 0; i < niveau; i++)
        for(int j = 0; j < niveau+1; j++)
            if(csp->matrice_contraintes->constraint_matrix[i][j]){
				//printf ("contrainte entre %d et %d\n", i, j);
                csp_bivalue->matrice_contraintes->constraint_matrix[i][j] = init_constraint(domain_size);
                csp_bivalue->matrice_contraintes->constraint_matrix[i][j]->max_domain = domain_size;
                for(int k = 0; k < domain_size;k++)
                    for(int t = 0; t < domain_size; t++){
						//printf ("k = %d, t = %d\n",k,t);
                        csp_bivalue->matrice_contraintes->constraint_matrix[i][j]->relations[k][t] = 0;
                        //printf ("if = %d\n", ( (k == (2*(affectation[niveau]-1))) || (k == (2*(affectation[niveau]-1)+1))) && (t == (2*(affectation[niveau]-1)) || (t == (2*(affectation[niveau]-1)+1))));
                        if(( (k == (2*(affectation[i]-1))) || (k == (2*(affectation[i]-1)+1))) && (t == (2*(affectation[j]-1)) || (t == (2*(affectation[j]-1)+1))))
                            csp_bivalue->matrice_contraintes->constraint_matrix[i][j]->relations[k][t] = csp->matrice_contraintes->constraint_matrix[i][j]->relations[k][t];
                    }
            }
            else
                csp_bivalue->matrice_contraintes->constraint_matrix[i][j] = NULL;
    return csp_bivalue;
}


/*marche pas vraiment encore, � la cr�ation du csp il faut bien choisir les valeurs, � remodifier, pour l'instant � tester que sur csp
  au domaine de taille pair pour eviter les soucis*/
int consistent(CSP * csp, int * affectation, int niveau, int size){
    CSP * csp_bivalue = create_csp(csp,affectation, niveau, size);
    //printf ("gello...\n");
    int vide = 1;
    AC8(csp_bivalue,NULL);
    for(int i=0; i < csp_bivalue->max_var; i++)
		for (int j=0; j<csp_bivalue->Domain->max_domain; j++)
				printf("domain[%d][%d] = %d \n",i, j, csp_bivalue->Domain->domain_matrix[i][j]);
    PC8(csp_bivalue);
    print_relation(csp_bivalue);
    /* soit modifier AC8/PC8, soit tester ici les domaines/relations ,si l'un est vide, alors c'est plus consistent et on retourne 0 */

    for (int i=0; i < niveau+1; i++)
    {
		//printf ("i = %d\n",i);
		vide = 1;
		for (int j=0; j < csp_bivalue->Domain->max_domain; j++)
			if (csp_bivalue->Domain->domain_matrix[i][j] == 1)
				vide = 0;
		if (vide == 1)
			return 0;
	}

	for (int i=0; i < niveau; i++)
		for (int k=0; k < niveau+1; k++)
		{
			//printf ("k = %d\n",k);
			vide = 1;
			if (csp_bivalue->matrice_contraintes->constraint_matrix[i][k] == NULL)
				vide = 0;
			else
			{
				for (int j=0; j < csp_bivalue->Domain->max_domain; j++)
					for (int l=0; l < csp_bivalue->Domain->max_domain; l++)
						if (csp_bivalue->matrice_contraintes->constraint_matrix[i][k]->relations[j][l] == 1)
							vide = 0;
			}
			if (vide == 1)
				return 0;
		}

    //free_csp(csp_bivalue);
    return 1;
}

int not_complete(int * array, int size){
    for(int i =0; i < size; i++)
        if(array[i] == 0)
            return 1;
    return 0;
}

int affecter(int * affectation, int niveau, int size){
    if(size%2 == 0){
        if(affectation[niveau]+1 > (int)size/2)
            return 0;
    }else{
        if(affectation[niveau]+1 > (int)(size + 2 - 1)/2) //arrondi vers le haut
            return 0;
    }
    affectation[niveau]++;
    return 1;
}

void solve_csp(CSP * csp){
    BackTrack(csp);
}

void bigmac(CSP *csp){
	printf ("\n*****************************BIGMAC***************************\n");
    CSP * bigmac_csp;
    int niveau = 0;
    int succes_affectation, succes_consistence;
    int max_var = csp->max_var;
    int taille_domaine = csp->Domain->max_domain;
    int * affectation; /* Un tableau d'affectation, pour l'instant on ne va pas implementer d'heuristique de choix de pair de variables
                        * On a donc que chaque variables a pour domaine taille_domaine/2 valeur possible.
                        * ainsi si elle vaut 1, alors on considerera le couple des 2 premiere valeurs, si elle vaut 3 le 3eme couple
                        * de valeur etc... 0 signifie non affect�.
                        */
    affectation = malloc(csp->max_var*sizeof(int));
    for(int i = 0; i < max_var; i++){affectation[i] = 0;}

    /* Algo : On affecte une valeur. Si ce n'est pas possible (domaine etudi� en entier
     * on arrete, pas de solutions.
     * On teste la double consistence sur le sous csp ensuite. Si ce n'est pas consistent
     * on test la valeur suivante, s'il n'y a plus de valeur suivante possible, on remonte d'un cran
     * On s'arrete quand on a explorer tout l'arbre
     */
    while(not_complete(affectation, max_var) || !succes_consistence){
		printf ("niveau = %d\n", niveau);
		succes_affectation = affecter(affectation, niveau, taille_domaine);
        printf ("succes_affectation = %d\n", succes_affectation);
        if(!succes_affectation){
            niveau--;
            if(niveau < 0){
                printf("pas de solutions\n");
                return;
            }
        }
        else
        {
			//printf ("blouf!!!!!!!!!!!!\n");
			succes_consistence = consistent(csp, affectation, niveau, taille_domaine);
			printf ("succes consistence = %d\n", succes_consistence);
			if(succes_consistence)
				niveau++;
			else{
				continue;
			}
		}
    }
    printf ("I'm out ! \n");
    printf ("niveau = %d\n", niveau);
    bigmac_csp = create_csp(csp, affectation, niveau-1, taille_domaine);
    printf ("creer\n");
    for(int i=0; i < bigmac_csp->max_var; i++)
		for (int j=0; j<bigmac_csp->Domain->max_domain; j++)
				printf("domain[%d][%d] = %d \n",i, j, bigmac_csp->Domain->domain_matrix[i][j]);
	print_relation(bigmac_csp);
    solve_csp(bigmac_csp);
}


